# fuel-consumption-end-to-end-ml
End to End Machine Learning Project on Fuel Consumption Prediction of 70s and 80s vehicles.
